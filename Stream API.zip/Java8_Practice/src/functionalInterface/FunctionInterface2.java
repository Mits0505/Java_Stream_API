package functionalInterface;

public interface FunctionInterface2 {
    public void sum(int a, int b);
}