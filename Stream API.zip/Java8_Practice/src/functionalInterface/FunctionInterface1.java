package functionalInterface;

public interface FunctionInterface1 {
    public void m1();
}