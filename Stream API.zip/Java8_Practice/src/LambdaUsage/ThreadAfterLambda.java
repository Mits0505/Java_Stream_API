package LambdaUsage;

public class ThreadAfterLambda {
    public static void main(String[] args) {
        Runnable r = () ->  System.out.println("Child Thread1.");

        Thread t1 = new Thread(r);
        t1.start();

        Thread t2 = new Thread(()-> System.out.println("Child Thread2."));
        t2.start();

        System.out.println("Main Thread.");
    }
}
