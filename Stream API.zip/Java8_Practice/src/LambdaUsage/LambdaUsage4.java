package LambdaUsage;

import functionalInterface.FunctionInterface4;

public class LambdaUsage4 {
    public static void main(String[] args) {
        FunctionInterface4 i = x -> x * x;
        System.out.println("Square of 10 is " + i.square(100));
    }
}
