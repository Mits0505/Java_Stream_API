package LambdaUsage;

class MyRunnable implements Runnable{
    @Override
    public void run() {
        System.out.println("Child Thread.");
    }
}
public class ThreadBeforeLambda {
    public static void main(String[] args) {
        Thread t = new Thread (new MyRunnable());
        t.start();

        System.out.println("Main Thread.");
    }
}
