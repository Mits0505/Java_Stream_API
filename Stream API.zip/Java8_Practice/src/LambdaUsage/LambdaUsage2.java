package LambdaUsage;

import functionalInterface.FunctionInterface2;

public class LambdaUsage2 {
    public static void main(String[] args) {
        FunctionInterface2 i = (a,b) -> System.out.println("Sum of "+a+" and "+b+" is "+(a+b));
        i.sum(100,200);
    }
}
