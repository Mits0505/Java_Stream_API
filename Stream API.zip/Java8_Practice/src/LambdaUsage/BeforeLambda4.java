package LambdaUsage;

import functionalInterface.FunctionInterface4;

public class BeforeLambda4 implements FunctionInterface4 {

    @Override
    public int square(int n) {
        return n*n;
    }

    public static void main(String[] args) {
        FunctionInterface4 i = new BeforeLambda4();
        System.out.println("Square of 10 is "+i.square(10));
    }
}
