package collections;

import java.util.TreeMap;

public class TreeMapSortingWithLambda {
    public static void main(String[] args) {
        TreeMap<Integer,String> tm = new TreeMap<>((a, b) -> (a > b) ? -1 : (a < b) ? 1 : 0);
        tm.put(30,"A");
        tm.put(10,"C");
        tm.put(60,"B");
        tm.put(80,"D");
        tm.put(90,"E");

        System.out.println("Map After Customized Sorting using Lambda: "+tm);
    }
}

