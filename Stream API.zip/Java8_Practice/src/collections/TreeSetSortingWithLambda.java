package collections;

import java.util.TreeSet;

public class TreeSetSortingWithLambda {
    public static void main(String[] args) {
        TreeSet<Integer> ts = new TreeSet<>((a,b)->(a>b)?-1:(a<b)?1:0);
        ts.add(20);
        ts.add(10);
        ts.add(60);
        ts.add(50);

        System.out.println("Set After Customized Sorting using Lambda: "+ts);
    }
}

